A Pen created at CodePen.io. You can find this one at http://codepen.io/hakimel/pen/FAiKv.

 A context-shift transition inspired by iOS.